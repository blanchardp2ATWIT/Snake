package com.example.snake_v4_1;

//this enum Direction class is used to set the directions in which our snake will move

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}

